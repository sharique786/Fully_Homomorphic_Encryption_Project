# Engineering Change Day Dashboard - Complete Setup Guide

## 📁 Project Structure Setup

### Step 1: Create Project Directory Structure

```bash
mkdir -p ecd-dashboard
cd ecd-dashboard

# Create backend structure
mkdir -p src/main/java/com/ecd/dashboard/{entity,repository,service,controller,config}
mkdir -p src/main/resources
mkdir -p src/test/java/com/ecd/dashboard

# Create frontend structure
mkdir -p src/main/frontend/{src,public}
mkdir -p src/main/frontend/src/components
```

### Step 2: Copy All Files

Place each artifact file in the correct location:

**Root Directory:**
- `pom.xml`
- `Dockerfile`
- `docker-compose.yml`
- `README.md`
- `SETUP_GUIDE.md` (this file)

**Backend Java Files** (`src/main/java/com/ecd/dashboard/`):
```
├── ECDDashboardApplication.java
├── entity/
│   ├── User.java
│   ├── Idea.java
│   ├── UserPreference.java
│   └── TeamAllocation.java
├── repository/
│   └── [Repository interfaces - all in one file]
├── service/
│   ├── UserService.java
│   ├── IdeaService.java
│   ├── PreferenceService.java
│   └── AllocationService.java
├── controller/
│   └── [All controllers - can be in one file or separate]
└── config/
    ├── SecurityConfig.java
    └── DataInitializer.java
```

**Backend Resources** (`src/main/resources/`):
- `application.properties`
- `ehcache.xml`

**Frontend Files** (`src/main/frontend/`):
```
├── package.json
├── tailwind.config.js
├── postcss.config.js
├── public/
│   └── index.html
└── src/
    ├── index.js
    ├── index.css
    └── App.jsx
```

## 🔧 Quick Start Options

### Option 1: Docker (Recommended for Production)

**Prerequisites:**
- Docker installed
- Docker Compose installed

**Steps:**
```bash
# 1. Build the Docker image
docker build -t ecd-dashboard:latest .

# 2. Run with docker-compose
docker-compose up -d

# 3. Check logs
docker-compose logs -f ecd-dashboard

# 4. Access application
# Open browser: http://localhost:8080

# 5. Stop application
docker-compose down
```

### Option 2: Maven Build (Local Development)

**Prerequisites:**
- Java 17+ installed
- Maven 3.8+ installed
- Node.js 18+ installed

**Steps:**
```bash
# 1. Install frontend dependencies
cd src/main/frontend
npm install
cd ../../..

# 2. Build entire project (includes React build)
mvn clean package

# 3. Run the application
java -jar target/dashboard-1.0.0.jar

# 4. Access application
# Open browser: http://localhost:8080
```

### Option 3: Development Mode (Hot Reload)

**Terminal 1 - Backend:**
```bash
mvn spring-boot:run
```

**Terminal 2 - Frontend:**
```bash
cd src/main/frontend
npm install
npm start
```

Access:
- Frontend (React Dev Server): http://localhost:3000
- Backend API: http://localhost:8080
- H2 Console: http://localhost:8080/h2-console

## 📝 Frontend Setup Details

### Create React App Structure

1. **public/index.html:**
```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta name="description" content="Engineering Change Day Dashboard" />
    <title>ECD Dashboard</title>
  </head>
  <body>
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
  </body>
</html>
```

2. **src/index.js:**
```javascript
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
```

3. **src/App.jsx:** (Use the React artifact provided)

4. **src/index.css:** (Use the Tailwind CSS setup from configuration artifact)

## 🗄️ Database Setup

### H2 In-Memory (Default - Development)

No setup needed! The application creates and initializes the database on startup.

Access H2 Console:
- URL: http://localhost:8080/h2-console
- JDBC URL: `jdbc:h2:mem:ecddb`
- Username: `sa`
- Password: (leave empty)

### PostgreSQL (Production)

1. **Install PostgreSQL:**
```bash
# Ubuntu/Debian
sudo apt-get install postgresql

# MacOS
brew install postgresql

# Docker
docker run --name ecd-postgres -e POSTGRES_PASSWORD=ecd_password -p 5432:5432 -d postgres:15
```

2. **Create Database:**
```sql
CREATE DATABASE ecddb;
CREATE USER ecd_user WITH PASSWORD 'ecd_password';
GRANT ALL PRIVILEGES ON DATABASE ecddb TO ecd_user;
```

3. **Update application.properties:**
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/ecddb
spring.datasource.username=ecd_user
spring.datasource.password=ecd_password
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
spring.jpa.hibernate.ddl-auto=update
```

4. **Add PostgreSQL dependency in pom.xml:**
```xml
<dependency>
    <groupId>org.postgresql</groupId>
    <artifactId>postgresql</artifactId>
    <scope>runtime</scope>
</dependency>
```

## 🧪 Testing the Application

### 1. Login with Demo Accounts

Open http://localhost:8080 and login:

**Admin Account:**
- Username: `admin`
- Password: `admin123`

**Approver Account:**
- Username: `approver`
- Password: `approver123`

**Normal User Account:**
- Username: `user_set1_1` (or any from 1-45)
- Password: `user123`

### 2. Test Complete Workflow

**Step 1 - Submit Ideas (Any User):**
1. Login as any user
2. Navigate to "Submit Idea"
3. Fill out the form:
    - Title: "Automated Deployment Pipeline"
    - Description: "CI/CD pipeline for faster releases"
    - Category: "Technology"
    - Impact Area: "Efficiency"
4. Submit

**Step 2 - Select Top 10 (Admin):**
1. Login as `admin`
2. Navigate to "All Ideas"
3. Select 5-10 ideas
4. Click "Submit Selected Ideas for Approval"

**Step 3 - Approve Ideas (Approver):**
1. Login as `approver`
2. Review selected ideas
3. Click "Approve" for each idea
    - Or click "Request Review" with notes

**Step 4 - Submit Preferences (Normal Users):**
1. Login as `user_set1_1`
2. Navigate to "My Preferences"
3. Select up to 3 ideas
4. Submit preferences
5. Repeat for several users (user_set1_2, user_set1_3, etc.)

**Step 5 - Generate Allocations (Admin):**
1. Login as `admin`
2. Trigger allocation algorithm for SET1
3. Review generated allocations

**Step 6 - Approve Allocations (Approver):**
1. Login as `approver`
2. Navigate to "Allocations"
3. Review team distributions
4. Click "Approve Allocations"

**Step 7 - Vote for Top 3 (Admin):**
1. Login as `admin`
2. Vote for best ideas
3. View top 3 in "Top Ideas" section

**Step 8 - View Results (All Users):**
1. All users can now see:
    - Final team allocations
    - Top 3 winning ideas

## 🔍 Monitoring & Debugging

### Application Logs
```bash
# Spring Boot logs
tail -f logs/spring.log

# Docker logs
docker logs -f ecd-dashboard

# Check health
curl http://localhost:8080/actuator/health
```

### H2 Console Queries
```sql
-- View all users
SELECT * FROM USERS;

-- View all ideas
SELECT * FROM IDEAS;

-- View preferences
SELECT u.username, i.title, p.preference_rank
FROM USER_PREFERENCES p
JOIN USERS u ON p.user_id = u.id
JOIN IDEAS i ON p.idea_id = i.id
ORDER BY u.username, p.preference_rank;

-- View allocations
SELECT i.title, COUNT(a.id) as team_size
FROM TEAM_ALLOCATIONS a
JOIN IDEAS i ON a.idea_id = i.id
GROUP BY i.title;
```

### Cache Statistics

Access EhCache statistics programmatically or add actuator:

```xml
<!-- Add to pom.xml -->
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
```

Access: http://localhost:8080/actuator/caches

## 🚀 Deployment

### AWS EC2 Deployment

```bash
# 1. Launch EC2 instance (Amazon Linux 2)
# 2. SSH into instance
ssh -i your-key.pem ec2-user@your-ec2-ip

# 3. Install Docker
sudo yum update -y
sudo yum install docker -y
sudo service docker start
sudo usermod -a -G docker ec2-user

# 4. Pull and run your image
docker pull yourusername/ecd-dashboard:latest
docker run -d -p 80:8080 --name ecd-dashboard yourusername/ecd-dashboard:latest

# 5. Configure security group to allow port 80

# 6. Access application
# http://your-ec2-public-ip
```

### Heroku Deployment

```bash
# 1. Install Heroku CLI
# 2. Login
heroku login

# 3. Create app
heroku create ecd-dashboard

# 4. Add PostgreSQL
heroku addons:create heroku-postgresql:hobby-dev

# 5. Deploy
git push heroku main

# 6. Open app
heroku open
```

### Docker Hub

```bash
# 1. Build image
docker build -t ecd-dashboard:latest .

# 2. Tag for Docker Hub
docker tag ecd-dashboard:latest yourusername/ecd-dashboard:latest

# 3. Login to Docker Hub
docker login

# 4. Push
docker push yourusername/ecd-dashboard:latest

# 5. Pull on any server
docker pull yourusername/ecd-dashboard:latest
docker run -d -p 8080:8080 yourusername/ecd-dashboard:latest
```

## 🔧 Troubleshooting

### Issue: Port 8080 already in use
```bash
# Find process
lsof -i :8080

# Kill process
kill -9 <PID>

# Or change port in application.properties
server.port=8081
```

### Issue: React build fails
```bash
cd src/main/frontend
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
npm run build
```

### Issue: Maven build fails
```bash
# Clean everything
mvn clean
rm -rf target/
rm -rf src/main/frontend/node_modules

# Rebuild
mvn clean install -U
```

### Issue: Database connection error
```bash
# Check H2 console
# Verify JDBC URL: jdbc:h2:mem:ecddb
# Username: sa
# Password: (empty)

# Check application.properties settings
```

### Issue: Cache not working
```bash
# Verify ehcache.xml in resources
# Check logs for cache initialization
# Restart application
```

## 📊 Performance Tips

1. **Increase Heap Size:**
```bash
java -Xmx2g -Xms1g -jar target/dashboard-1.0.0.jar
```

2. **Optimize Cache:**
```xml
<!-- Increase cache size in ehcache.xml -->
<heap unit="entries">500</heap>
```

3. **Database Pooling:**
```properties
spring.datasource.hikari.maximum-pool-size=10
spring.datasource.hikari.minimum-idle=5
```

## 🎯 Next Steps

After successful setup:

1. **Customize Company Logo:**
    - Replace logo in React component
    - Update branding colors in tailwind.config.js

2. **Add Email Notifications:**
    - Integrate Spring Mail
    - Send notifications for approvals

3. **Enhanced Security:**
    - Implement JWT authentication
    - Add role-based access control
    - Enable HTTPS

4. **Analytics:**
    - Add Spring Boot Actuator
    - Integrate with monitoring tools
    - Create admin analytics dashboard

5. **Testing:**
    - Write unit tests
    - Add integration tests
    - Implement e2e tests with Selenium

## 📞 Support

If you encounter issues:
1. Check logs: `docker logs ecd-dashboard`
2. Verify all files are in correct locations
3. Ensure all prerequisites are installed
4. Review this guide step-by-step

---

**Good luck with your Engineering Change Day Dashboard! 🚀**