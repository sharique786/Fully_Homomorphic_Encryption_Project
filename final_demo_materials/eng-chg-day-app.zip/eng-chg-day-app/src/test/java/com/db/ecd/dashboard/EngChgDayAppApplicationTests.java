package com.db.ecd.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EngChgDayAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
