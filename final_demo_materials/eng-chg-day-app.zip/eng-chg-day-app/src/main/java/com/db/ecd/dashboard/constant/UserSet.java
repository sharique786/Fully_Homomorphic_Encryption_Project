package com.db.ecd.dashboard.constant;

public enum UserSet {
    SET1, SET2
}
