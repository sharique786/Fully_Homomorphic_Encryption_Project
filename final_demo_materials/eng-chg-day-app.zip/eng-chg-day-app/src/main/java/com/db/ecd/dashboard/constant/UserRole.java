package com.db.ecd.dashboard.constant;

public enum UserRole {
    NORMAL, ADMIN, APPROVER
}