package com.db.ecd.dashboard.constant;

public enum IdeaStatus {
    PENDING, SELECTED, APPROVED, REVIEW_REQUESTED
}
