# Security Considerations:

See our [security notes](https://openfhe-development.readthedocs.io/en/latest/sphinx_rsts/intro/security.html) for a discussion on
the CKKS scheme and important security notes.
