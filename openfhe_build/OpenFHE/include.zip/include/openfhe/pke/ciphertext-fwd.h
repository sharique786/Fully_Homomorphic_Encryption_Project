//==================================================================================
// BSD 2-Clause License
//
// Copyright (c) 2014-2022, NJIT, Duality Technologies Inc. and other contributors
//
// All rights reserved.
//
// Author TPOC: contact@openfhe.org
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.
//
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//==================================================================================
/*
 * It is a lightweight file to be included where we need the declaration of Ciphertext only
 */
#ifndef __CIPHERTEXT_FWD_H__
#define __CIPHERTEXT_FWD_H__

#include <cstdint>
#include <memory>
#include <vector>

namespace lbcrypto {

template <typename Element>
class CiphertextImpl;

template <typename Element>
using Ciphertext = std::shared_ptr<CiphertextImpl<Element>>;

template <typename Element>
using ConstCiphertext = const std::shared_ptr<const CiphertextImpl<Element>>;

// reqiured for std::vector
template <typename Element>
using ReadOnlyCiphertext = std::shared_ptr<const CiphertextImpl<Element>>;

template <typename Element>
struct seriesPowers {
    std::vector<Ciphertext<Element>> powersRe;
    std::vector<Ciphertext<Element>> powers2Re;
    ConstCiphertext<Element> power2km1Re;
    uint32_t k;
    uint32_t m;
    std::vector<Ciphertext<Element>> powersIm;
    std::vector<Ciphertext<Element>> powers2Im;
    ConstCiphertext<Element> power2km1Im;

    seriesPowers() = default;

    ~seriesPowers() = default;

    explicit seriesPowers(const std::vector<Ciphertext<Element>>& powers0) : powersRe(powers0) {}

    seriesPowers(const std::vector<Ciphertext<Element>>& powers0, const std::vector<Ciphertext<Element>>& powers1)
        : powersRe(powers0), powersIm(powers1) {}

    seriesPowers(const std::vector<Ciphertext<Element>>& powers0, const std::vector<Ciphertext<Element>>& powers20,
                 ConstCiphertext<Element>& power2km10, uint32_t k0, uint32_t m0)
        : powersRe(powers0), powers2Re(powers20), power2km1Re(power2km10), k(k0), m(m0) {}

    seriesPowers(const std::vector<Ciphertext<Element>>& powers0, const std::vector<Ciphertext<Element>>& powers20,
                 ConstCiphertext<Element>& power2km10, uint32_t k0, uint32_t m0,
                 const std::vector<Ciphertext<Element>>& powers1, const std::vector<Ciphertext<Element>>& powers21,
                 ConstCiphertext<Element>& power2km11)
        : powersRe(powers0),
          powers2Re(powers20),
          power2km1Re(power2km10),
          k(k0),
          m(m0),
          powersIm(powers1),
          powers2Im(powers21),
          power2km1Im(power2km11) {}
};

}  // namespace lbcrypto

#endif  // __CIPHERTEXT_FWD_H__
